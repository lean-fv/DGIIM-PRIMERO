/***************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// (C) FRANCISCO JOS� CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACI�N E INTELIGENCIA ARTIFICIAL
//
// RELACI�N DE PROBLEMAS 6
// Problema: Clase Recta (apartado d)
// 
/* 	Implementaci�n de la clase "Recta" para representar una recta en el plano.
	Una recta viene determinada por tres coeficientes A, B, C, de forma que 
	todos los puntos (x,y) que pertenecen a la recta verifican lo siguiente 
	(ecuaci�n general de la recta):

		Ax + By + C = 0

	Para que A, B y C sean coeficientes de una recta, A y B no pueden ser 
	simultaneamente cero. Estableceremos una precondici�n para los valores 
	de estos coeficientes que obligue a filtrar adecuadamente los valores 
	leidos antes de crear la recta. 

	Apartado d) Pol�tica de acceso a los datos miembros ---> Un s�lo 
	m�todo que inicializa todos los coeficientes
		
	Definici�n de la clase Recta (b�sica) con datos miembro privados 
	e implementaci�n de los m�todos p�blicos para:
		* Obtener un string con la ecuaci�n general. 
		* Calcular la pendiente.
		* Obtener la ordenada (y) dado un valor de abscisa (x)
		* Obtener la abscisa (x) dado un valor de ordenada (y).
		* M�todos Set (uno por campo) para establecer su valor. 
		* M�todos Get (uno por campo) para leer su valor. 
		
		Nuevos m�todos p�blicos: 
		
		* M�todo SetCoeficientes para inicializar y/o modificar los 
		  valores de los coeficientes A, B, y C simultaneamente. 

	lee seis reales desde teclado (coeficientes de dos rectas) y una vez 
	validados los usa para crear dos dos objetos "Recta" (emplea ahora 
	un �nico m�todo "SetCoeficientes"). Despu�s, imprime la ecuaci�n 
	general de las rectas creadas. 
		
	El resto es igual: calcula e imprime la pendiente de cada recta, lee 
	un valor de abscisa y se imprime la ordenada y finalmente lee un 
	valor de ordenada y se imprime la abscisa que le corresponde 
	(s�lo con la primera recta).	
*/
/***************************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

/////////////////////////////////////////////////////////////////////////////
/* 
	La clase "Recta" representa una recta en el plano.
	Una recta viene determinada por tres coeficientes A, B, C, de forma que 
	todos los puntos (x,y) que pertenecen a la recta verifican lo siguiente 
	(ecuaci�n general de la recta):

		Ax + By + C = 0
*/

class Recta
{
	
private: 
	
	double A, B, C; // Coeficientes

	// PRE: A y B no pueden ser ambos 0 
	//
	// Los m�todos de la clase acceden SIEMPRE libremente a los datos 
	// (campos) del objeto impl�cito.
	// Por estar declarados private, YA NO podr� accederse a �stos desde 
	// cualquier funci�n que est� en el �mbito de la clase. 
	// Se proporcionan m�todos p�blicos de acceso para lectura o escritura.
	
public:

	/*****************************************************************/
	// M�todo (�nico) de acceso para escritura 
	// PRE: A y B no pueden ser ambos 0 
	
	void SetCoeficientes (double valor_A, double valor_B, double valor_C) 
	{
		A = valor_A;
		B = valor_B;	
		C = valor_C;		
	}

	/*****************************************************************/
	// M�todos de acceso para lectura

	double GetA (void) 
	{
		return (A);	
	}
	
	double GetB (void) 
	{
		return (B);	
	}

	double GetC (void) 
	{
		return (C);	
	}
	
	/*****************************************************************/
	// M�todo de c�lculo: Devuelve la pendiente de la recta
	// 
	// PRE: B != 0
	
	double Pendiente (void) 
	{
		return (-A / B);	
	}
	
	/*****************************************************************/
	// M�todo de c�lculo: Devuelve la ordenada (y) dada la abscisa (x) 
	// 
	// Recibe: x, valor de la abscisa
	// Devuelve: el valor de la ordenada que le corresponde a "x"
	//
	// PRE: B != 0
	
	double Ordenada (double x) 
	{
		return ((-C - A*x) / B);	
	}
	
	/*****************************************************************/
	// M�todo de c�lculo: Devuelve la abscisa (x) dada la ordenada (y) 
	//
	// Recibe: y, valor de la ordenada
	// Devuelve: el valor de la abscisa que le corresponde a "y"
	//
	// PRE: A != 0
	
	double Abscisa (double y) 
	{
		return ((-C - B*y) / A);	
	}

	/**********************************************************************/
	// Devuelve un string con la expresi�n de la recta usando el patr�n: 
	//    [+|-] A x [+|-] B y [+|-] C = 0

	string ToString (void) 
	{
		string cad, signo;
		
		if (A!=0) {
			if (A>0) signo = "+";
			else signo = "";
			cad = signo + to_string(A) + " x ";
		}		
		
		if (B!=0) {
			if (B>0) signo = "+";
			else signo = "";
			cad = cad + signo + to_string(B) + " y ";
		}	
		 
		if (C!=0) {
			if (C>0) signo = "+";
			else signo = "";
		cad = cad + signo + to_string(C);
		}	

		cad += " = 0";
		
		return (cad);
	}
		
	/**********************************************************************/
};

/////////////////////////////////////////////////////////////////////////////

/***************************************************************************/
int main (void)
{
	cout.setf(ios::fixed);		// Notaci�n de punto fijo para los reales
	cout.setf(ios::showpoint);	// Mostrar siempre decimales 
	
	double A, B, C; // Coeficientes 


	// Leer coeficientes
	
	bool error_coeficientes;
	
	cout << "Coeficientes de la primera recta (Ax + By + C = 0): " << endl;
	
	// Aseguramos las precondiciones para la primera recta con este filtro

	do {
		cout << "\tA: ";
		cin >> A;
	
		cout << "\tB: ";
		cin >> B;
		
		// Recta imposible si A=0 y B=0
		error_coeficientes = ((A == 0) && (B == 0));
		
		if (error_coeficientes)
			cout << "\tError: A y B no pueden ser, a la vez, cero." << endl;
			
	} while (error_coeficientes);
		
	cout << "\tC: ";
	cin >> C;
	
	
	// Declaraci�n del objeto recta1 (de clase Recta)
	
	Recta recta1; // Los campos del objeto contienen "basura" 
	
	// Inicializaci�n del objeto recta1: se emplea un �nico m�todo 
	// p�blico de escritura.
	
	recta1.SetCoeficientes (A, B, C);
	
	// Mostrar la ecuaci�n general 
	
	cout << endl; 
	cout << "Recta 1: " << recta1.ToString() << endl;
	cout << endl; 
	
	
	
	cout << "Coeficientes de la segunda recta (Ax + By + C = 0): " << endl;

	// Aseguramos las precondiciones para la primera recta con este filtro

	do {
		cout << "\tA: ";
		cin >> A;
	
		cout << "\tB: ";
		cin >> B;
		
		// Recta imposible si A=0 y B=0
		error_coeficientes = ((A == 0) && (B == 0));
		
		if (error_coeficientes)
			cout << "\tError: A y B no pueden ser, a la vez, cero." << endl;
			
	} while (error_coeficientes);
		
	cout << "\tC: ";
	cin >> C;
	
	
	// Declaraci�n del objeto recta2 (de clase Recta)
	
	Recta recta2; // Los campos del objeto contienen "basura" 
	
	// Inicializaci�n del objeto recta2: se emplea un �nico m�todo 
	// p�blico de escritura.
	
	recta2.SetCoeficientes (A, B, C);
	
	
	// Mostrar la ecuaci�n general 
	
	cout << endl; 
	cout << "Recta 2: " << recta2.ToString() << endl;
	cout << endl; 
			
	
	
	// C�lculo y presentaci�n de la pendiente de cada recta
	// IMPORTANTE: Hay que asegurarse que se cumplen las precondiciones 
	// antes de llamar al m�todo "Pendiente"
		
	cout << endl;

	if (recta1.GetB() != 0) 
		cout << "Recta 1. Pendiente = " << setw(5) 
			 << setprecision (2) << recta1.Pendiente() << endl;
	else 
		cout << "Recta 1. Pendiente = infinito " 
			 << "(paralela al eje de ordenadas)." << endl; 
	
	if (recta2.GetB() != 0) 
		cout << "Recta 2. Pendiente = " << setw(5) 
			 << setprecision (2) << recta2.Pendiente() << endl;
	else 
		cout << "Recta 2. Pendiente = infinito " 
			 << "(paralela al eje de ordenadas)." << endl; 
	
	// M�todos "Ordenada" y "Abscisa" 
	// IMPORTANTE: Hay que asegurarse que se cumplen las precondiciones 
	// antes de llamar a los m�todos 

	double x, y; 
	
	// Lectura de la abscisa y c�lculo de la ordenada 
		
	cout << endl;
	cout << "Valor de la abscisa (x) = " ;
	cin >> x;
	
	if (recta1.GetB() != 0) 
		cout << "Recta 1. abscisa = " << setw(5) << setprecision (2) 
			 << x << " ordenada = " << setw(5) << setprecision (2) 
			 << recta1.Ordenada(x) << endl;
	else 
		cout << "Recta 1 paralela al eje de ordenadas --> " 
			 << " infinitos valores para la ordenada." << endl; 
	
	// Lectura de la ordenada y c�lculo de la abscisa 

	cout << endl;
	cout << "Valor de la ordenada (y) = " ;
	cin >> y;
	
	if (recta1.GetA() != 0) 
		cout << "Recta 1. ordenada = " << setw(5) << setprecision (2) 
			 << y << " abscisa = " << setw(5) << setprecision (2) 
			 << recta1.Abscisa(y) << endl;
	else 
		cout << "Recta 1 paralela al eje de abscisas --> " 
			 << " infinitos valores para la abscisa." << endl; 
	
	cout << endl << endl;
	
	return 0;
}
