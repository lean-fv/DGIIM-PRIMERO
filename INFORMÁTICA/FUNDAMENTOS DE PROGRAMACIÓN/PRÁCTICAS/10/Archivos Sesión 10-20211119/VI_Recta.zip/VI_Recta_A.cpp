/***************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
//
// (C) FRANCISCO JOS� CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACI�N E INTELIGENCIA ARTIFICIAL
//
// RELACI�N DE PROBLEMAS 6
// Problema: Clase Recta (apartado a)
// 
/* 	Implementaci�n de la clase "Recta" para representar una recta en el plano.
	Una recta viene determinada por tres coeficientes A, B, C, de forma que 
	todos los puntos (x,y) que pertenecen a la recta verifican lo siguiente 
	(ecuaci�n general de la recta):

		Ax + By + C = 0

	Para que A, B y C sean coeficientes de una recta, A y B no pueden ser 
	simultaneamente cero. Estableceremos una precondici�n para los valores 
	de estos coeficientes que obligue a filtrar adecuadamente los valores 
	leidos antes de crear la recta. 
	
	Apartado a) Definici�n de la clase y creaci�n de objetos
	Definici�n de la clase Recta (b�sica) con datos miembro p�blicos.
	
	lee seis reales desde teclado (coeficientes de dos rectas) y una vez 
	validados los usa para crear dos dos objetos "Recta". Despu�s, imprime 
	la ecuaci�n general de las rectas creadas. 
	
	En esta versi�n solamente calcula e imprime la pendiente de cada recta 
	en la funci�n main. 	
*/
/***************************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

/////////////////////////////////////////////////////////////////////////////
/* 
	La clase "Recta" representa una recta en el plano.
	Una recta viene determinada por tres coeficientes A, B, C, de forma que 
	todos los puntos (x,y) que pertenecen a la recta verifican lo siguiente 
	(ecuaci�n general de la recta):

		Ax + By + C = 0
*/

class Recta
{
	
public: 
	
	double A, B, C; // Coeficientes

	// PRE: A y B no pueden ser ambos 0 
	//
	// Los m�todos de la clase acceden SIEMPRE libremente a los datos 
	// (campos) del objeto impl�cito.
	//
	// Por estar declarados P�BLICOS, tambi�n podr� accederse a �stos  
	// DESDE CUALQUIER FUNCI�N que est� en el �mbito de la clase.
	// El acceso se realizar� para lectura o escritura, sin restricci�n.
	// Es evidente que deber� modificarse la pol�tica de acceso.
	
};

/////////////////////////////////////////////////////////////////////////////

/***************************************************************************/
int main (void)
{
	cout.setf(ios::fixed);		// Notaci�n de punto fijo para los reales
	cout.setf(ios::showpoint);	// Mostrar siempre decimales 
	
	double A, B, C; // Coeficientes 

	string cad, signo; // Para mostrar la recta
	

	// Leer coeficientes
	
	bool error_coeficientes;
	
	cout << "Coeficientes de la primera recta (Ax + By + C = 0): " << endl;
	
	// Aseguramos las precondiciones para la primera recta con este filtro

	do {
		cout << "\tA: ";
		cin >> A;
	
		cout << "\tB: ";
		cin >> B;
		
		// Recta imposible si A=0 y B=0
		error_coeficientes = ((A == 0) && (B == 0));
		
		if (error_coeficientes)
			cout << "\tError: A y B no pueden ser, a la vez, cero." << endl;
			
	} while (error_coeficientes);
		
	cout << "\tC: ";
	cin >> C;
	
	// Declaraci�n del objeto recta1 (de clase Recta)
		
	Recta recta1; // Los campos del objeto contienen "basura" 
	
	// Inicializaci�n de los objetos
	
	recta1.A = A;	// Observar el acceso (escritura) a los 
	recta1.B = B;	// datos del objeto "recta1".   
	recta1.C = C;	// No hay ninguna restricci�n (son public)
	
	
	// Componer cadena [+|-] A x [+|-] B y [+|-] C = 0
	
	if (recta1.A!=0) {
		if (recta1.A>0) signo = "+";
		else signo = "";
		cad = signo + to_string(recta1.A) + " x ";
	}		
	
	if (recta1.B!=0) {
		if (recta1.B>0) signo = "+";
		else signo = "";
		cad = cad + signo + to_string(recta1.B) + " y ";
	}	
	 
	if (recta1.C!=0) {
		if (recta1.C>0) signo = "+";
		else signo = "";
	cad = cad + signo + to_string(recta1.C);
	}	

	cad += " = 0";
		
	cout << endl; 
	cout << "Recta 1: " << cad << endl;
	cout << endl; 
				
	
	

	cout << "Coeficientes de la segunda recta (Ax + By + C = 0): " << endl;

	// Aseguramos las precondiciones para la primera recta con este filtro

	do {
		cout << "\tA: ";
		cin >> A;
	
		cout << "\tB: ";
		cin >> B;
		
		// Recta imposible si A=0 y B=0
		error_coeficientes = ((A == 0) && (B == 0));
		
		if (error_coeficientes)
			cout << "\tError: A y B no pueden ser, a la vez, cero." << endl;
			
	} while (error_coeficientes);
		
	cout << "\tC: ";
	cin >> C;
	
	// Declaraci�n del objeto recta2 (de clase Recta)
		
	Recta recta2; // Los campos del objeto contienen "basura" 
	
	// Inicializaci�n de los objetos
	
	recta2.A = A;	// Observar el acceso (escritura) a los 
	recta2.B = B;	// datos del objeto "recta2".   
	recta2.C = C;	// No hay ninguna restricci�n (son public)
	
	
	// Componer cadena [+|-] A x [+|-] B y [+|-] C = 0
		
	if (recta2.A!=0) {
		if (recta2.A>0) signo = "+";
		else signo = "";
		cad = signo + to_string(recta2.A) + " x ";
	}		
	
	if (recta2.B!=0) {
		if (recta2.B>0) signo = "+";
		else signo = "";
		cad = cad + signo + to_string(recta2.B) + " y ";
	}	
	 
	if (recta2.C!=0) {
		if (recta2.C>0) signo = "+";
		else signo = "";
	cad = cad + signo + to_string(recta2.C);
	}	

	cad += " = 0";
		
	cout << endl; 
	cout << "Recta 2: " << cad << endl;
	cout << endl; 
				

	
	// C�lculo y presentaci�n de la pendiente de cada recta
	
	double pendiente_recta1, pendiente_recta2;
	
	pendiente_recta1 = (-recta1.A) / recta1.B;
	pendiente_recta2 = (-recta2.A) / recta2.B;
	
	cout << endl;
	cout << "Recta 1. Pendiente = " << setw(5) 
		 << setprecision (2) << pendiente_recta1 << endl;
	cout << "Recta 2. Pendiente = " << setw(5) 
		 << setprecision (2) << pendiente_recta2 << endl;
	cout << endl << endl;
	
	return 0;
}
