/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#define __USE_MP_SCALE__
#include "MPTests.h"

using namespace std;


int main() {

    MAIN_BODY() {
    }
    RETURN_MAIN(0);
}